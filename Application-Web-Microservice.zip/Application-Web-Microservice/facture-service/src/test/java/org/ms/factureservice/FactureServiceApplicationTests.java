package org.ms.factureservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactureServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
