package org.ms.factureservice.web;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.ms.factureservice.entities.Facture;
import org.ms.factureservice.entities.FactureLigne;
import org.ms.factureservice.entities.StatutFacture;
import org.ms.factureservice.feign.ClientServiceClient;
import org.ms.factureservice.feign.ProduitServiceClient;
import org.ms.factureservice.model.Client;
import org.ms.factureservice.model.Produit;
import org.ms.factureservice.repositories.FactureLigneRepository;
import org.ms.factureservice.repositories.FactureRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import jakarta.persistence.criteria.Join;


@RestController
@RequestMapping("/api")
public class FactureRestController {
	
	@Value("${globalParam}")
	private int globalParam;
	@Value("${monParam}")
	private int monParam;
	@Value("${email}")
	private String email;
	
	
	private FactureRepository factureRepository;
	private FactureLigneRepository factureLigneRepository;
	private ClientServiceClient clientServiceClient;
	private ProduitServiceClient produitServiceClient;

	public FactureRestController(FactureRepository factureRepository, FactureLigneRepository factureLigneRepository,
			ClientServiceClient clientServiceClient, ProduitServiceClient produitServiceClient) {

		this.factureRepository = factureRepository;
		this.factureLigneRepository = factureLigneRepository;
		this.clientServiceClient = clientServiceClient;
		this.produitServiceClient = produitServiceClient;
	}
	
	@GetMapping("/config")
	public Map<String,Object> config () {
	Map<String,Object> params = new Hashtable<>();
	params.put("globalParam", globalParam);
	params.put("monParam", monParam);
	params.put("email", email);
	params.put("threadName", Thread.currentThread().toString());
	return params;
	}
	
	/*
	 * @GetMapping(path = "/factures") public List<Facture> getAllFactures() {
	 * return factureRepository.findAll(); }
	 */
	
	@GetMapping(path = "/factures")
	public ResponseEntity<?> getAllFacture() {
	    List<Facture> factures = factureRepository.findAll(); // Récupérer toutes les factures
	    List<FactureLigne> lignes = new ArrayList<>();
	    for (FactureLigne ligne : lignes) {
	        if (ligne.getProduitId() != null) {
	            Produit produit = produitServiceClient.findProductById(ligne.getProduitId());
	            ligne.setProduit(produit);
	        }
	    }
	    return ResponseEntity.ok(factures); // Retourner la liste des factures avec un code 200 OK
	}
	
	@PostMapping(path = "/factures")
	public Facture createFacture(@RequestBody Facture facture) {
	    // Vérifiez si le client existe
	    Client client = clientServiceClient.findClientById(facture.getClientID());
	    if (client == null) {
	        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Client not found");
	    }
	    // Validez et corrigez les lignes de facture
	    List<FactureLigne> lignesValides = new ArrayList<>();
	    facture.getFacturelignes().forEach(fl -> {
	        if (fl.getProduitId() != null) {
	            try {
	                Produit product = produitServiceClient.findProductById(fl.getProduitId());
	                fl.setProduit(product);
	                fl.setFacture(facture);
	                lignesValides.add(fl); // Ajoute uniquement les lignes valides
	            } catch (Exception e) {
	                System.out.println("Produit avec ID " + fl.getProduitId() + " introuvable.");
	            }
	        } else {
	            System.out.println("Ligne ignorée : ProduitId est null.");
	        }
	    });

	    // Vérifiez les lignes valides
	    System.out.println("Lignes valides après validation : " + lignesValides);

	    // Remplace les lignes de facture par les lignes valides
	    facture.setFacturelignes(lignesValides);
	    
	    // Calculer le montant total
	    facture.calculerMontantTotal();
	    System.out.println("Montant total calculé : " + facture.getMontantTotal());

	    // Sauvegarde de la facture
	    return factureRepository.save(facture);
	}



	@PutMapping(path = "/factures/{id}")
	public Facture updateFacture(@PathVariable(name = "id") Long id, @RequestBody Facture updatedFacture) {
	    // Récupérez la facture existante
	    Facture existingFacture = factureRepository.findById(id).get();

	    // Mettez à jour les informations de base
	    existingFacture.setDateFacture(updatedFacture.getDateFacture());
	    existingFacture.setStatut(updatedFacture.getStatut());
	    existingFacture.setClientID(updatedFacture.getClientID());

	    // Vérifiez si le client existe
	    Client client = clientServiceClient.findClientById(updatedFacture.getClientID());
	    if (client == null) {
	        throw new RuntimeException("Client non trouvé !");
	    }
	    existingFacture.setClient(client);

	    // Préparez une nouvelle liste pour les lignes de facture mises à jour
	    List<FactureLigne> updatedFactureLignes = new ArrayList<>();
	    for (FactureLigne fl : updatedFacture.getFacturelignes()) {
	        Produit product = produitServiceClient.findProductById(fl.getProduitId());
	        if (product == null) {
	            throw new RuntimeException("Produit non trouvé !");
	        }

	        // Mettre à jour les détails de la ligne de facture
	        fl.setProduit(product);
	        fl.setFacture(existingFacture);

	        // Ajouter à la nouvelle liste
	        updatedFactureLignes.add(fl);
	    }

	    // Remplacez les lignes de facture existantes
	    existingFacture.setFacturelignes(updatedFactureLignes);

	    // Sauvegarde de la facture mise à jour
	    return factureRepository.save(existingFacture);
	}

	@GetMapping("/factures/statut/non-reglee")
	public List<Facture> findByStatutNonReglee() {
	    List<Facture> factures = factureRepository.findByStatut(StatutFacture.NON_REGLEE);

	    // Récupérer tous les produits
	    List<Produit> products = produitServiceClient.getAllProduits();

	    // Ajouter une ligne de facture pour chaque produit
	    List<FactureLigne> factureLignes = new ArrayList<>();
	    products.forEach(product -> {
	        FactureLigne factureLigne = new FactureLigne();
	        factureLigne.setProduitId(product.getId());
	        factureLigne.setPrice(product.getPrice());
	        factureLigne.setNbreProduit(product.getQuantite());
	        factureLignes.add(factureLigne);
	    });
			    return factures;
	}
	
	@GetMapping("/factures/statut/reglee")
	public List<Facture> findByStatutReglee() {
	    List<Facture> factures = factureRepository.findByStatut(StatutFacture.REGLEE);

	    // Récupérer tous les produits
	    List<Produit> products = produitServiceClient.getAllProduits();

	    // Ajouter une ligne de facture pour chaque produit
	    List<FactureLigne> factureLignes = new ArrayList<>();
	    products.forEach(product -> {
	        FactureLigne factureLigne = new FactureLigne();
	        factureLigne.setProduitId(product.getId());
	        factureLigne.setPrice(product.getPrice());
	        factureLigne.setNbreProduit(product.getQuantite());
	        factureLignes.add(factureLigne);
	    });
			    return factures;
	}
	
	@GetMapping(path = "/factures/produits/sollicites")
	public Map<String, Long> getProduitsLesPlusSollicites() {
	    return factureRepository.findAll().stream()
	        .flatMap(facture -> facture.getFacturelignes().stream())
	        .filter(ligne -> ligne.getProduitId() != null && ligne.getProduit() != null) // Vérifier nulls
	        .collect(Collectors.groupingBy(
	        		ligne -> ligne.getProduit().toString(), // Utiliser une référence de méthode
	            Collectors.counting()
	        ));
	}

	//récupérer une facture selon l'Id 
	@GetMapping(path = "/factures/{id}")
	public ResponseEntity<?> getFactureById(@PathVariable Long id) {
	    try {
	        Facture facture = factureRepository.findById(id).orElse(null);
	        if (facture == null) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                .body("Facture not found for ID: " + id);
	        }
	        return ResponseEntity.ok(facture);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	            .body("Error fetching facture: " + e.getMessage());
	    }
	}


	@GetMapping(path = "/factures/search")
	public List<Facture> searchFactures(
	    @RequestParam(name = "factureId", required = false) Long factureId,
	    @RequestParam(name = "clientId", required = false) Long clientId,
	    @RequestParam(name = "date", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
	    @RequestParam(name = "statut", required = false) StatutFacture statut,
	    @RequestParam(name = "produitId", required = false) Long produitId
	) {
	    // Utilisation de Specification pour gérer les critères dynamiques
	    Specification<Facture> specification = Specification.where(null);

	    if (factureId != null) {
	        specification = specification.and((root, query, criteriaBuilder) ->
	            criteriaBuilder.equal(root.get("id"), factureId));
	    }

	    if (clientId != null) {
	        specification = specification.and((root, query, criteriaBuilder) ->
	            criteriaBuilder.equal(root.get("clientID"), clientId));
	    }

	    if (date != null) {
	        specification = specification.and((root, query, criteriaBuilder) ->
	            criteriaBuilder.equal(root.get("dateFacture"), date));
	    }

	    if (statut != null) {
	        specification = specification.and((root, query, criteriaBuilder) ->
	            criteriaBuilder.equal(root.get("statut"), statut));
	    }

	    if (produitId != null) {
	        specification = specification.and((root, query, criteriaBuilder) -> {
	            Join<Object, Object> lignesFacture = root.join("facturelignes");
	            return criteriaBuilder.equal(lignesFacture.get("produitId"), produitId);
	        });
	    }

	    // Recherche avec les critères
	    return factureRepository.findAll(specification);
	}
	
	@GetMapping(path = "/factures/client/topClient")
	public List<String> getClientsLesPlusFidelesAvecTexte() {
	    // Récupérer toutes les factures
	    List<Facture> factures = factureRepository.findAll();

	    // Grouper par client et compter les factures
	    Map<Long, Long> clientsFidelite = factures.stream()
	        .collect(Collectors.groupingBy(
	            Facture::getClientID, // Grouper par client
	            Collectors.counting() // Compter les factures par client
	        ));

	    // Trier les clients par nombre de factures et retourner le top 10 avec un texte
	    return clientsFidelite.entrySet().stream()
	        .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue())) // Trier par nombre de factures
	        .limit(10) // Limiter au top 10
	        .map(entry -> "Client ID: " + entry.getKey() + " - Nombre de factures: " + entry.getValue()) // Ajouter du texte
	        .collect(Collectors.toList());
	}
	
	@GetMapping(path = "/factures/produits/topProduits")
	public List<String> getProduitsLesPlusVendus() {
	    // Récupérer toutes les factures
	    List<Facture> factures = factureRepository.findAll();

	    // Grouper par produit (ProduitId) et compter les occurrences dans les lignes de facture
	    Map<Long, Long> produitsVendus = factures.stream()
	        .flatMap(facture -> facture.getFacturelignes().stream()) // Aplatir les lignes de facture
	        .collect(Collectors.groupingBy(
	            FactureLigne::getProduitId, // Grouper par ID produit
	            Collectors.counting() // Compter les occurrences de chaque produit
	        ));

	    // Trier les produits par nombre de ventes et retourner le top 10 avec du texte
	    return produitsVendus.entrySet().stream()
	        .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue())) // Trier par nombre de ventes
	        .limit(10) // Limiter au top 10
	        .map(entry -> "Produit ID: " + entry.getKey() + " - Nombre de ventes: " + entry.getValue()) // Ajouter du texte
	        .collect(Collectors.toList());
	}
	
	
	@GetMapping(path = "/factures/produits/PlusVendus")
	public Map<Integer, List<String>> getProduitsLesPlusVendusParAnnee(
	        @RequestParam(value = "annee", required = false) Integer annee) {
	    // Récupérer toutes les factures
	    List<Facture> factures = factureRepository.findAll();

	    // Grouper les factures par année
	    Map<Integer, List<Facture>> facturesParAnnee = factures.stream()
	    		.filter(facture -> facture.getDateFacture() != null)
	            .collect(Collectors.groupingBy(
	                    facture -> facture.getDateFacture().getYear()
	            ));

	    // Si une année spécifique est demandée, ne conserver que cette année
	    if (annee != null) {
	        facturesParAnnee = facturesParAnnee.entrySet().stream()
	                .filter(entry -> entry.getKey().equals(annee))
	                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
	    }

	    // Calculer les produits les plus vendus pour chaque année
	    Map<Integer, List<String>> resultatsParAnnee = new HashMap<>();
	    for (Map.Entry<Integer, List<Facture>> entry : facturesParAnnee.entrySet()) {
	        Integer anneeCourante = entry.getKey();
	        List<Facture> facturesPourAnnee = entry.getValue();

	        // Grouper par produit et compter les occurrences
	        Map<Long, Long> produitsVendus = facturesPourAnnee.stream()
	                .flatMap(facture -> facture.getFacturelignes().stream())
	                .collect(Collectors.groupingBy(
	                        FactureLigne::getProduitId,
	                        Collectors.counting()
	                ));

	        // Trier les produits par nombre de ventes et limiter au top 10
	        List<String> topProduits = produitsVendus.entrySet().stream()
	                .sorted((entry1, entry2) -> Long.compare(entry2.getValue(), entry1.getValue()))
	                .limit(10)
	                .map(entryProd -> "Produit ID: " + entryProd.getKey() + " - Nombre de ventes: " + entryProd.getValue())
	                .collect(Collectors.toList());

	        // Ajouter les résultats pour l'année en cours
	        resultatsParAnnee.put(anneeCourante, topProduits);
	    }

	    return resultatsParAnnee;
	}


	@GetMapping("/factures/dettes")
	public List<String> getDettesParClient() {
	    // Récupérer toutes les factures non réglées
	    List<Facture> facturesNonReglees = factureRepository.findAll()
	        .stream()
	        .filter(facture -> facture.getStatut() != StatutFacture.REGLEE) // Filtrer les factures non réglées
	        .collect(Collectors.toList());

	    // Grouper les factures par client et calculer les dettes
	    Map<Long, Double> dettesParClient = facturesNonReglees.stream()
	        .collect(Collectors.groupingBy(
	            Facture::getClientID, // Grouper par ID client
	            Collectors.summingDouble(Facture::getMontantTotal) // Calculer la somme des montants impayés
	        ));

	    // Convertir les dettes en texte lisible
	    return dettesParClient.entrySet().stream()
	        .map(entry -> {
	            Long clientId = entry.getKey();
	            Double totalDette = entry.getValue();
	            return "Client ID: " + clientId + " - Total dette: " + totalDette + " €";
	        })
	        .collect(Collectors.toList());
	}

	//récupérer les factures d'un client 
	@GetMapping(path = "/factures/client/{clientId}")
    public List<Facture> getFacturesByClientId(@PathVariable(name = "clientId") Long clientId) {
        // Récupérer toutes les factures du client spécifié
        List<Facture> factures = factureRepository.findByClientID(clientId);
        
        // Charger les détails du client et des produits pour chaque facture
        factures.forEach(facture -> {
            // Récupérer les informations du client
            Client client = clientServiceClient.findClientById(facture.getClientID());
            facture.setClient(client);
            
            // Récupérer les informations des produits dans chaque ligne de facture
            facture.getFacturelignes().forEach(fl -> {
                Produit produit = produitServiceClient.findProductById(fl.getProduitId());
                fl.setProduit(produit);
            });
        });
        return factures;
    }
	

	 @GetMapping(path = "/factures/getAllClients")
	    public ResponseEntity<?> getAllClients() {
	        try {
	            List<Client> clients = clientServiceClient.findAllClients(); // Méthode dans le Client Feign
	            if (clients.isEmpty()) {
	                return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body("No clients found.");
	            }
	            return ResponseEntity.ok(clients);
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error fetching clients: " + e.getMessage());
	        }
	    }
	 
	 @GetMapping(path = "/factures/getAllProducts")
	    public ResponseEntity<?> getAllProducts() {
	        try {
	            List<Produit> produits = produitServiceClient.getAllProduits(); // Méthode dans le produit Feign
	            if (produits.isEmpty()) {
	                return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body("No produits found.");
	            }
	            return ResponseEntity.ok(produits);
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("Error fetching produits: " + e.getMessage());
	        }
	    }
	 
	 @GetMapping(path = "/factures/getProduct/{id}")
	 public ResponseEntity<?> getProductById(@PathVariable Long id) {
	     try {
	         Produit produit = produitServiceClient.findProductById(id); // Appel au client Feign
	         if (produit == null) {
	             return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                 .body("Produit with ID " + id + " not found.");
	         }
	         return ResponseEntity.ok(produit);
	     } catch (Exception e) {
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	             .body("Error fetching produit: " + e.getMessage());
	     }
	 }

	
}
