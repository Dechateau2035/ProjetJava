package org.ms.factureservice.dto;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor @AllArgsConstructor
public class FactureDTO {
    private Long id;
    private Date dateFacture;
    private Long clientID;
    private String statut;
    private Double montantTotal;
    private List<FactureLigneDTO> facturelignes;
}
