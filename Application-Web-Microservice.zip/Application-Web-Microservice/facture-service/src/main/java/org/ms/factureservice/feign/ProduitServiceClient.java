package org.ms.factureservice.feign;

import java.util.List;

import org.ms.factureservice.model.Produit;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.web.PagedModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name="PRODUIT-SERVICE", url = "${PRODUIT-SERVICE.url}")
public interface ProduitServiceClient {

	@GetMapping
	List<Produit> getAllProduits();
	
	//@GetMapping
	//List<Produit> findProductsById(@RequestParam("ids") List<Long> ids);
	
	//@GetMapping("/produits/{id}")
	//List<Produit> findProductById(@PathVariable Long id);

	
	@GetMapping(path="/{id}")
	Produit findProductById(@PathVariable Long id);
}
