package org.ms.factureservice.entities;

import java.util.*;

import org.ms.factureservice.model.Client;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class Facture {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Date dateFacture;
	
	@Transient
	private Client client;
	
	private Long clientID;
	
	private StatutFacture statut;
	
	private Double montantTotal;
	
	@OneToMany(mappedBy = "facture", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Collection<FactureLigne> facturelignes = new ArrayList<>();
	
	public void calculerMontantTotal() {
	    if (facturelignes != null) {
	        this.montantTotal = facturelignes.stream()
	            .mapToDouble(ligne -> ligne.getNbreProduit() * ligne.getProduit().getPrice())
	            .sum();
	    } else {
	        this.montantTotal = 0.0;
	    }
	}
	
	@PrePersist
	@PreUpdate
	public void calculerMontantTotalAutomatique() {
	    calculerMontantTotal();
	}


}
