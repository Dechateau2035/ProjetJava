package org.ms.factureservice.dto;

import java.util.Collection;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor @AllArgsConstructor
public class FactureLigneDTO {
    private Long produitId;
    private String name;
    private String description;
    private int quantite;
    private double price;
}
