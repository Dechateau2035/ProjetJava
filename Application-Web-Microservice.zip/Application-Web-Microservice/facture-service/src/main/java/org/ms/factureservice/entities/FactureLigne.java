package org.ms.factureservice.entities;

import org.ms.factureservice.model.Produit;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class FactureLigne {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	
	@JsonProperty("ProduitId")
	private Long ProduitId;
	
	private int nbreProduit;
	
	private double Price;
	
	@ToString.Exclude
	@JoinColumn(name = "ProduitId")
	@Transient
	private Produit produit;
	
	@ManyToOne@ToString.Exclude
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@JoinColumn(name = "facture_id")
	private Facture facture;
	
	public void calculerPrix() {
	    if (produit != null) {
	        this.Price = produit.getPrice() * this.nbreProduit;
	    } else {
	        this.Price = 0.0;
	    }
	}
	
	@PrePersist
	@PreUpdate
	public void calculerMontantTotalAutomatique() {
		calculerPrix();
	}
}
