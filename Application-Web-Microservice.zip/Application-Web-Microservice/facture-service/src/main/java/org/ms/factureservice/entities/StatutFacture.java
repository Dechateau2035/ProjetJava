package org.ms.factureservice.entities;

public enum StatutFacture {
	REGLEE,
    NON_REGLEE
}
