package org.ms.factureservice.repositories;

import java.util.List;

import org.ms.factureservice.entities.Facture;
import org.ms.factureservice.entities.StatutFacture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

public interface FactureRepository extends JpaRepository<Facture, Long> , JpaSpecificationExecutor<Facture>{ 
	List<Facture> findByClientID(Long clientID);
    List<Facture> findByStatut(StatutFacture statut);
    @Query("SELECT f FROM Facture f")
    //@Query("SELECT f FROM Facture f JOIN FETCH f.facturelignes fl JOIN FETCH fl.produit")
    List<Facture> findAllWithLignesAndProduits();
}
