package org.ms.reglementservice.web;

import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import org.ms.reglementservice.entities.Reglement;
import org.ms.reglementservice.feign.FactureServiceClient;
import org.ms.reglementservice.model.Facture;
import org.ms.reglementservice.repositories.ReglementRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import feign.FeignException;

@RefreshScope
@RestController
@RequestMapping("/api/reglements")
public class ReglementRestController {
/*
    @Value("${globalParam}")
    private int globalParam;
    //@Value("${monParam}")
    //private int monParam;
    @Value("${email}")
    private String email;
*/
    private final ReglementRepository reglementRepository;
    private final FactureServiceClient factureService;

    public ReglementRestController(ReglementRepository reglementRepository, FactureServiceClient factureService) {
        this.reglementRepository = reglementRepository;
        this.factureService = factureService;
    }
/*
    @GetMapping("/config")
    public Map<String, Object> config() {
        Map<String, Object> params = new Hashtable<>();
        params.put("threadName", Thread.currentThread().toString());
        params.put("globalParam", globalParam);
        //params.put("monParam", monParam);
        params.put("email", email);
        return params;
    }*/
    
    @PostMapping
    public Reglement createReglement(@RequestBody Reglement paiement) {
        // Vérifie si la facture existe
        Facture facture = factureService.findFactureById(paiement.getFactureId());
        if (facture == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Facture non trouvée");
        }

        // Vérifie que le montant payé est valide
        if (paiement.getMontantPaye() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le montant payé doit être supérieur à 0");
        }

        // Vérifie que le paiement ne dépasse pas le montant de la facture
        if (paiement.getMontantPaye() > facture.getMontantTotal()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le montant payé ne peut pas dépasser le total de la facture");
        }

        // Log les informations sur le paiement
        System.out.println("Paiement effectué : " + paiement);
        System.out.println("Reste à payer : " + (facture.getMontantTotal() - paiement.getMontantPaye()));

        // Sauvegarde du paiement
        Reglement savedReglement = reglementRepository.save(paiement);
        System.out.println("Paiement sauvegardé avec succès : " + savedReglement);

        return savedReglement;
    }


    @GetMapping("/ChiffreAffairesGlobal")
    public Double getChiffreAffairesGlobal() {
        // Récupérer toutes les factures
        List<Facture> factures = factureService.getAllFactures(); // Ou une méthode appropriée pour obtenir les factures

        // Calculer le chiffre d'affaires global à partir des montants totaux des factures et des paiements
        double totalFactures = factures.stream()
            .mapToDouble(Facture::getMontantTotal) // Calculer le montant total des factures
            .sum();

        // Ajouter le montant total des paiements (règlements)
		
		  double totalReglements = reglementRepository.findAll().stream()
		  .mapToDouble(Reglement::getMontantPaye) // Utilisez la méthode correcte pour obtenir le montant d'un règlement 
		  .sum();
		 

        // Retourner le chiffre d'affaires global (factures + règlements)
        return totalFactures + totalReglements;
    }


    @GetMapping("/ChiffreAffairesParAnnee")
    public Map<Integer, Double> getChiffreAffairesParAnnee() {
        // Récupérer toutes les factures
        List<Facture> factures = factureService.getAllFactures();

        // Récupérer tous les règlements
        List<Reglement> reglements = reglementRepository.findAll();

        // Calculer le chiffre d'affaires par année pour les factures
        Map<Integer, Double> chiffreAffairesFacturesParAnnee = factures.stream()
            .collect(Collectors.groupingBy(
                facture -> facture.getDateFacture().toInstant().atZone(ZoneId.systemDefault()).getYear(), // Extraire l'année
                Collectors.summingDouble(Facture::getMontantTotal)
            ));

        // Calculer le chiffre d'affaires par année pour les règlements
        Map<Integer, Double> chiffreAffairesReglementsParAnnee = reglements.stream()
            .collect(Collectors.groupingBy(
                reglement -> reglement.getDatePaiement().toInstant().atZone(ZoneId.systemDefault()).getYear(), // Extraire l'année
                Collectors.summingDouble(Reglement::getMontantPaye)
            ));

        // Fusionner les deux cartes en additionnant les valeurs pour chaque année
        Map<Integer, Double> chiffreAffairesParAnnee = new HashMap<>(chiffreAffairesFacturesParAnnee);

        chiffreAffairesReglementsParAnnee.forEach((annee, montant) ->
            chiffreAffairesParAnnee.merge(annee, montant, Double::sum)
        );

        return chiffreAffairesParAnnee;
    }

    @GetMapping("/ResteGlobalImpayes")
    public Double getResteGlobalImpayes() {
        try {
            List<Facture> nonReglees = factureService.findMontantTotalByStatut();
            return nonReglees.stream()
                    .mapToDouble(facture -> {
                        List<Reglement> reglements = reglementRepository.findByFactureId(facture.getId());
                        double montantPaye = reglements.stream().mapToDouble(Reglement::getMontantPaye).sum();
                        return facture.getMontantTotal() - montantPaye;
                    }).sum();
        } catch (FeignException e) {
            // Log the Feign-specific error
            e.printStackTrace();
            throw new RuntimeException("Erreur Feign : " + e.getMessage(), e);
        } catch (Exception e) {
            // Log other errors
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de la récupération des factures non réglées.", e);
        }
    }

}
