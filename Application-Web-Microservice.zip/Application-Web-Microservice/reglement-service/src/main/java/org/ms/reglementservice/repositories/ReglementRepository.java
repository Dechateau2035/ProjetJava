package org.ms.reglementservice.repositories;

import java.util.List;

import org.ms.reglementservice.entities.Reglement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ReglementRepository extends JpaRepository<Reglement, Long>, JpaSpecificationExecutor<Reglement> {
    List<Reglement> findByFactureId(Long factureId);
}
