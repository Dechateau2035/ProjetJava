package org.ms.reglementservice.feign;

import java.util.List;

import org.ms.reglementservice.model.Facture;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="FACTURE-SERVICE", url="${FACTURE-SERVICE.url}")
public interface FactureServiceClient {

	@GetMapping
	List<Facture> getAllFactures();
	
	@GetMapping(path="/MontantTotal")
	List<Facture> findFactureByMontantTotal();
	
	@GetMapping(path="/{id}")
	Facture findFactureById(@PathVariable(name="id") Long id);
	
	@GetMapping(path="/non-reglee")
	List<Facture> findMontantTotalByStatut();
	
	@GetMapping(path="/client/{id}")
	Facture findFactureByClientID(@PathVariable(name="id") Long id);
}
