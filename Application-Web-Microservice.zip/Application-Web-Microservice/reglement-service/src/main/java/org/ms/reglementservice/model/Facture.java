package org.ms.reglementservice.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class Facture {

	private Long id;
	private Date dateFacture;
	private Long clientID;
	private Double montantTotal;
	private StatutFacture statut;
}
