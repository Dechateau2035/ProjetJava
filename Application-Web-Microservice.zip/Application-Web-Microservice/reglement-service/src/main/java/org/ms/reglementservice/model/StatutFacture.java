package org.ms.reglementservice.model;

public enum StatutFacture {
	REGLEE,
    NON_REGLEE
}
