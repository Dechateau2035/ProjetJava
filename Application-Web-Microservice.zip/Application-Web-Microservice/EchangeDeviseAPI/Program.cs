using EchangeDeviseAPI.Service;
using Steeltoe.Discovery.Client;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Ajout des services HttpClient et DeviseService
builder.Services.AddHttpClient<DeviseService>();

// Ajouter les contr�leurs
builder.Services.AddControllers();

// Add Steeltoe Discovery Client
builder.Services.AddDiscoveryClient(builder.Configuration);

builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(5002);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configuration des routes
//app.MapControllers();

app.UseHttpsRedirection();

app.UseAuthorization();

// Use Discovery Client
app.UseDiscoveryClient();

app.MapControllers();

app.Run();
