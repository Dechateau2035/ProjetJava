using ClientAPI.Model;
using ClientAPI.Repositorie;
using Microsoft.EntityFrameworkCore;
using Steeltoe.Discovery.Client;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHealthChecks();


//Inscription du service de contexte
var connectionString = builder.Configuration.GetConnectionString("DBConnection");
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));

//Injection du service
builder.Services.AddScoped<IClientRepository, ClientRepository>();

// Add Steeltoe Discovery Client
builder.Services.AddDiscoveryClient(builder.Configuration);

//Activation du service Cors
builder.Services.AddCors();

builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(5000);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());


//app.UseHttpsRedirection();

app.UseHealthChecks("/actuator/health");

app.UseAuthorization();

// Use Discovery Client
app.UseDiscoveryClient();

app.MapControllers();

app.Run();
