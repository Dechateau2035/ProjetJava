﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClientAPI.Migrations
{
    /// <inheritdoc />
    public partial class dddd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Modifie la colonne Price pour s'assurer qu'elle est de type float
            migrationBuilder.AlterColumn<float>(
                name: "Price",
                table: "Produits",
                type: "real", // Cela définit la colonne comme étant de type 'real' (qui correspond à float en SQL Server)
                nullable: false,
                oldClrType: typeof(decimal), // Si le type précédent était decimal, vous devez préciser l'ancien type
                oldType: "decimal(18,2)"); // Spécifiez le type précédent (par exemple, decimal avec 18 chiffres et 2 décimales)
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Annule le changement de type, en restaurer la colonne avec le type précédent (par exemple decimal)
            migrationBuilder.AlterColumn<decimal>(
                name: "Price",
                table: "Produits",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(float),
                oldType: "real");
        }
    }
}
