﻿namespace ProduitAPI.Dto
{
    public class ProduitDetailsDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Quantite { get; set; }
        public string CategorieName { get; set; }
    }
}
