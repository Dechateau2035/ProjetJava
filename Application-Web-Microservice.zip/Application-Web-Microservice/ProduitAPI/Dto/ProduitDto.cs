﻿namespace ProduitAPI.Dto
{
    public class ProduitDto
    {
        public string Name { get; set; }
        public string? Description { get; set; }
        public float Price { get; set; }
        public int Quantite { get; set; }
        public int CategorieId { get; set; }
    }
}
